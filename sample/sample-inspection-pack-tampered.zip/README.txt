How to verify this inspection pack
===================================

1. Install the one dependency:

     pip install cryptography

2. From inside this extracted directory, run:

     python verify.py .

   No flags needed: verify.py reads manifest.json and detects on its own
   that this is an AS 1215 archive-inspection-pack export, not a
   dispute-action packet.

3. Expected output on a clean, unmodified pack:

     VERIFIED (archive export): ledger chain intact, workpaper set matches attestation

   Any modification to any file in this pack produces "VERIFICATION
   FAILED" followed by one or more named failure codes, and a non-zero
   exit code (1). Exit code 2 means the 'cryptography' package from
   step 1 is missing.

Optional, additional checks (ask whoever issued this pack for the
relevant trust root if you want these):

     --tsa-ca-cert PATH    verify the embedded RFC 3161 timestamp against a CA bundle
     --sth-public-key HEX  verify the embedded SCITT transparency receipt against a public key

This pack requires no ActaSeal account, no install beyond the one
dependency above, and no network access -- verify.py never makes a
network call.

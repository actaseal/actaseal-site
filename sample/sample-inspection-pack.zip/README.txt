How to verify this inspection pack
===================================

1. Install the one dependency:

     pip install cryptography

2. From inside this extracted directory, run:

     python verify.py .

   No flags needed: verify.py reads manifest.json and detects on its own
   that this is an AS 1215 archive-inspection-pack export, not a
   dispute-action packet.

3. Expected output on a clean, unmodified pack:

     VERIFIED (archive export): ledger chain intact, workpaper set matches attestation

   Any modification to any file in this pack produces "VERIFICATION
   FAILED" followed by one or more named failure codes, and a non-zero
   exit code (1). Exit code 2 means the 'cryptography' package from
   step 1 is missing.

What "VERIFIED" proves, and what it does NOT: by itself, VERIFIED means
this pack's ledger hash chain is intact and its workpaper-set hash
matches what the attestation inside the pack commits to -- in other
words, nothing has been tampered with SINCE this pack was assembled.
It does NOT mean an independent third party witnessed the assembly.
Both of those independent-witness checks are optional, because this
pack cannot supply their trust roots itself -- a public key or CA cert
embedded in the pack would prove nothing (whoever assembled a fabricated
pack could just embed a key of their own that matches their own
fabricated receipt). Get the real trust root out of band -- ask whoever
issued this pack, or (for a live deployment) fetch its published key
from its own /.well-known/actaseal-keys.json -- and run:

     --tsa-ca-cert PATH    verify the embedded RFC 3161 timestamp against a CA bundle
     --sth-public-key HEX  verify the embedded SCITT transparency receipt against a public key

If you run `python verify.py .` with neither flag, verify.py's own
output will say so by name: "RFC 3161 timestamp NOT verified" and
"SCITT transparency receipt NOT verified", each with the reason. That is
not a failure -- VERIFIED still means what it always means -- it is a
named gap in what was checked, so you can decide whether to close it.

This pack requires no ActaSeal account, no install beyond the one
dependency above, and no network access -- verify.py never makes a
network call.
